import tkinter

from tkinter import *


import time

import mysql.connector




#made by: sanjay kumar

win=tkinter.Tk()
win.geometry("800x524")
win.resizable(0, 0)
win.title("calculator")
win.configure(background='black')





##########################







def sgtn():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="database1"
    )

    mycursor = mydb.cursor()

    sql = "INSERT INTO `pyth` (Message) VALUES (sugsn_text.get(1.0, "end-1c"))"

    mycursor.execute(sql, val)

    mydb.commit()

    msg_label=tkinter.Label(win,text="message sent successfully", fg = "White",font=("sans-serif",10,"bold"), width =33, height =1, bd =4, bg = "maroon")
    msg_label.place(x=25,y=324)
    msg_label.after(2000,msg_label.destroy)
    sugsn_text.delete("1.0", "end")

sugsn=tkinter.Label(win,text="Type your suggestions or Tools you need!", fg = "White",font=("sans-serif",10,"bold"), width =33, height =1, bd =4, bg = "maroon", cursor = "arrow")
sugsn.place(x=23,y=324)
sugsn_text=tkinter.Text(win, bg="white", bd=2, fg = "black", font=("sans-serif",10,"bold"),width=38,height=5)
sugsn_text.place(x=20,y=360)
sugsn_submit=Button(win, text = "Submit", fg = "White",font=("sans-serif",10,"bold"), width =6, height = 1, bd =4, bg = "maroon", cursor = "hand2",command=sgtn).place(x=292,y=468)



#################################################################
########################CALCULATOR###############################
###############################################################

def calc():

        def btn_click(item):
            nonlocal expression
            expression = expression + str(item)
            input_text.set(expression)

            # 'bt_clear' function :This is used to clear
            # the input field

        def bt_clear():
            nonlocal expression
            expression = ""
            input_text.set("")

            # 'bt_equal':This method calculates the expression
            # present in input field

        def bt_equal():
            nonlocal expression
            result = str(eval(expression))  # 'eval':This function is used to evaluates the string expression directly
            input_text.set(result)
            expression = ""

        expression = ""


        # 'StringVar()' :It is used to get the instance of input field
        btns_frame = tkinter.Frame(win, bg="#00A170", width=370, height=430, bd=4, relief="groove").place(x=417, y=70)

        input_text = StringVar()

        input_field = Entry(btns_frame,font=('arial', 18, 'bold'), textvariable=input_text, width=20, bg="#eee", bd=0,justify=RIGHT).place(x=433,y=84)
        clear = Button(btns_frame, text = "C", fg = "black", width =4, height =2, bd=2, bg = "#eee", cursor = "hand2", command = lambda: bt_clear()).place(x=650,y=129)

        divide = Button(btns_frame, text = "/", fg = "black", width = 4, height = 2, bd=2, bg = "#eee", cursor = "hand2", command = lambda: btn_click("/")).place(x=650,y=370)

    # second row

        seven = Button(btns_frame, text = "7", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(7)).place(x=440,y=190)

        eight = Button(btns_frame, text = "8", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(8)).place(x=510,y=190)

        nine = Button(btns_frame, text = "9", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(9)).place(x=580,y=190)

        multiply = Button(btns_frame, text = "*", fg = "black",width=4,height=2, bd=2, bg = "#eee", cursor = "hand2", command = lambda: btn_click("*")).place(x=650,y=190)

        # third row

        four = Button(btns_frame, text = "4", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(4)).place(x=440,y=250)

        five = Button(btns_frame, text = "5", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(5)).place(x=510,y=250)

        six = Button(btns_frame, text = "6", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(6)).place(x=580,y=250)

        minus = Button(btns_frame, text = "-", fg = "black",width=4,height=2, bd=2, bg = "#eee", cursor = "hand2", command = lambda: btn_click("-")).place(x=650,y=250)

        # fourth row

        one = Button(btns_frame, text = "1", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(1)).place(x=440,y=310)

        two = Button(btns_frame, text = "2", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(2)).place(x=510,y=310)

        three = Button(btns_frame, text = "3", fg = "black",width=4,height=2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(3)).place(x=580,y=310)

        plus = Button(btns_frame, text = "+", fg = "black",width=4,height=2, bd=2, bg = "#eee", cursor = "hand2", command = lambda: btn_click("+")).place(x=650,y=310)

        # fourth row

        zero = Button(btns_frame, text = "0", fg = "black", width = 4, height = 2, bd=2, bg = "#fff", cursor = "hand2", command = lambda: btn_click(0)).place(x=440,y=370)

        point = Button(btns_frame, text = ".", fg = "black",width=4,height=2, bd=2, bg = "#eee", cursor = "hand2", command = lambda: btn_click(".")).place(x=510,y=370)

        equals = Button(btns_frame, text = "=", fg = "black",width=4,height=2, bd=2, bg = "#eee", cursor = "hand2", command = lambda: bt_equal()).place(x=580,y=370)
Calc = Button(win, text = "1.Calculator                  ", fg = "White",font=("sans-serif",10,"bold"), width = 19, height = 1, bd =4, bg = "crimson", cursor = "hand2",command=calc).place(x=511,y=17)

win.mainloop()