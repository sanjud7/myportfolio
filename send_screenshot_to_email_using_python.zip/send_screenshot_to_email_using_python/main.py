import  pyautogui
import os
import smtplib
import imghdr
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email import encoders

from email.message import EmailMessage

#from--> mail address and pswd
EMAIL_ADDRESS = 'youremail'
EMAIL_PASSWORD =' yourpassword'



msg = EmailMessage()
msg['Subject'] = 'hello,this is from python!'
msg['From'] = EMAIL_ADDRESS
msg['To'] = 'to-mail adrress' #recievers mail address

msg.set_content('This is a plain text email')


#taking screenshot
im1 = pyautogui.screenshot()
im1.save('my_screenshot.png')


with open('my_screenshot.png','rb') as m:

    file_data = m.read()
    file_type = imghdr.what(m.name)
    file_name=m.name

part=MIMEBase('application','octet-stream')
part.set_payload(file_data)
encoders.encode_base64(part)
part.add_header('Content-Disposition',"attachment;filename="+file_name)


msg.add_attachment(file_data,maintype='image',subtype=file_type,filename=file_name)
#etablishing mail server
with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
    smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
    smtp.send_message(msg)

#sanjay kumar