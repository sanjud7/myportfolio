from selenium import webdriver
import time

driver = webdriver.Chrome(executable_path="C:\webdrivers\chromedriver.exe") #adjust path of the driver with your respective path

driver.maximize_window()

driver.get('https://www.instagram.com/')

driver.find_element_by_xpath('/html/body/div[1]/section/main/article/div[2]/div[1]/div/form/div[2]/div/label/input').send_keys('yourusername')
sleep(5)
driver.find_element_by_xpath('/html/body/div[1]/section/main/article/div[2]/div[1]/div/form/div[3]/div/label/input').send_keys('yourpassword')
sleep(5)
driver.find_element_by_xpath('/html/body/div[1]/section/main/article/div[2]/div[1]/div/form/div[4]/button/div').click()
sleep(5)
driver.find_element_by_xpath('/html/body/div[4]/div/div/div[3]/button[2]').click()
sleep(5)
#sanjay kumar


